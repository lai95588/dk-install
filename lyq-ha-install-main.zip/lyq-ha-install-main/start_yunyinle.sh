#!/bin/bash
docker exec nodered /bin/bash -c "cd /data/NeteaseCloudMusicApi && node app.js"
